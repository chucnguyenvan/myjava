//package com.codegym.dao.repository;
//
//import com.codegym.dao.entity.BookingDetail;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface BookingDetailRepository extends JpaRepository<BookingDetail,Integer> {
//}
