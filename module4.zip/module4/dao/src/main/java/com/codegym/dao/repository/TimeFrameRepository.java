package com.codegym.dao.repository;

import com.codegym.dao.entity.TimeFrame;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TimeFrameRepository extends JpaRepository<TimeFrame,Integer> {
}
