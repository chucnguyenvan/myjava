package com.codegym.dao.repository;

import com.codegym.dao.entity.Movie;
import com.codegym.dao.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order,Integer> {
//    Order findAllByIdOrder(int id);
//    Order  findByIdOrder(Long id);
}
