package com.codegym.service;

public interface BookingDetailService {
}
