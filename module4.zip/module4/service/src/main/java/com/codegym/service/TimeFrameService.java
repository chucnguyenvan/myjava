package com.codegym.service;

public interface TimeFrameService {
}
