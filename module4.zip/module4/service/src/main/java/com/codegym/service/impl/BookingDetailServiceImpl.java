package com.codegym.service.impl;

import com.codegym.service.BookingDetailService;

public class BookingDetailServiceImpl implements BookingDetailService {
}
