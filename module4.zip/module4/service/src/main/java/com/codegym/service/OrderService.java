package com.codegym.service;

import com.codegym.dao.entity.Movie;
import com.codegym.dao.entity.Order;

import java.util.List;

public interface OrderService {
    List<Order> findAllByDeletedIsFalse();

//    List<Movie> getNameMovie(String name);

//    Order findById(int id);
//    void updateOrder(Order order);
//    void save(Order order);
}
